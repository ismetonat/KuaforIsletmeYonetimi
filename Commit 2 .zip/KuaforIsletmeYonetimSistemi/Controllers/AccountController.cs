﻿using Microsoft.AspNetCore.Mvc;
using BCrypt.Net;
using Microsoft.AspNetCore.Http;
using System.Linq;

public class AccountController : Controller
{
    private readonly KuaforYonetimDbContext _context;

    public AccountController(KuaforYonetimDbContext context)
    {
        _context = context;
    }

    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(string email, string password)
    {
        var user = _context.Users.FirstOrDefault(u => u.Email == email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
        {
            ViewBag.Error = "Geçersiz e-posta veya şifre.";
            return View();
        }

        HttpContext.Session.SetString("UserRole", user.Role);
        if (user.Role == "Admin")
        {
            return RedirectToAction("AdminDashboard", "Home");
        }
        else
        {
            return RedirectToAction("UserDashboard", "Home");
        }
    }

    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(string fullName, string email, string password, string confirmPassword)
    {
        if (password != confirmPassword)
        {
            ViewBag.Error = "Şifreler eşleşmiyor.";
            return View();
        }

        var passwordHash = BCrypt.Net.BCrypt.HashPassword(password);

        var newUser = new Users
        {
            FullName = fullName,
            Email = email,
            PasswordHash = passwordHash,
            Role = "User"
        };

        _context.Users.Add(newUser);
        _context.SaveChanges();

        ViewBag.Message = "Kayıt başarıyla tamamlandı.";
        return RedirectToAction("Login");
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}
