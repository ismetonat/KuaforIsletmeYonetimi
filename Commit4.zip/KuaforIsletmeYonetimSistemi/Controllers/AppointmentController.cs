﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;

public class AppointmentController : Controller
{
    private readonly KuaforYonetimDbContext _context;

    public AppointmentController(KuaforYonetimDbContext context)
    {
        _context = context;
    }

    // Randevuları Listeleme
    public IActionResult Index(string searchQuery, DateTime? dateFilter)
    {
        var appointments = _context.Appointments.AsQueryable();

        if (!string.IsNullOrEmpty(searchQuery))
        {
            appointments = appointments.Where(a =>
                a.CustomerName.Contains(searchQuery) ||
                a.EmployeeName.Contains(searchQuery) ||
                a.ServiceType.Contains(searchQuery));
        }

        if (dateFilter.HasValue)
        {
            appointments = appointments.Where(a => a.AppointmentDate == dateFilter.Value);
        }

        return View(appointments.ToList());
    }

    // Yeni Randevu Ekleme Sayfası
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Appointment appointment)
    {
        // Geçmiş tarih kontrolü
        if (appointment.AppointmentDate < DateTime.Now.Date)
        {
            ViewBag.Error = "Geçmiş tarihe yönelik randevu alınamaz.";
            return View(appointment);
        }

        // Çakışma kontrolü
        var conflictingAppointment = _context.Appointments
            .FirstOrDefault(a => a.AppointmentDate == appointment.AppointmentDate && a.AppointmentTime == appointment.AppointmentTime);

        if (conflictingAppointment != null)
        {
            ViewBag.Error = "Bu tarih ve saatte zaten bir randevu var.";
            return View(appointment);
        }

        if (ModelState.IsValid)
        {
            _context.Appointments.Add(appointment);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        return View(appointment);
    }

    // Randevu Silme
    public IActionResult Delete(int id)
    {
        var appointment = _context.Appointments.Find(id);
        if (appointment != null)
        {
            _context.Appointments.Remove(appointment);
            _context.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}
