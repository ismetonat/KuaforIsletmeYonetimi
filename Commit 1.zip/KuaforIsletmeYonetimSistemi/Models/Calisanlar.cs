﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Calisanlar
{
    [Key]
    public int Id { get; set; }

    [Required]
    public string AdSoyad { get; set; }

    public string Uzmanlik { get; set; }

    // Foreign Key: Salonlar tablosuna bağlı
    [ForeignKey("Salon")]
    public int SalonId { get; set; }
    public Salonlar Salon { get; set; }
}
