﻿using KuaforIsletmeYonetimSistemi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace KuaforIsletmeYonetimSistemi.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly KuaforYonetimDbContext _context; // Veritabanı bağlamı

        public HomeController(ILogger<HomeController> logger, KuaforYonetimDbContext context)
        {
            _logger = logger;
            _context = context; // Veritabanı bağlamını kullanmak için
        }

        // Index Action: Veritabanından veriler çekiliyor ve View'a gönderiliyor
        public IActionResult Index()
        {
            var salonlar = _context.Salonlar.ToList(); // Salonlar tablosundan tüm verileri çek
            return View(salonlar); // View'a veri gönder
        }

        // Privacy Action: ViewBag ile mesaj gönderme örneği
        public IActionResult Privacy()
        {
            ViewBag.Message = "Bu, gizlilik politikası sayfasıdır.";
            return View();
        }

        // Error Action: Hata görüntüleme
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
