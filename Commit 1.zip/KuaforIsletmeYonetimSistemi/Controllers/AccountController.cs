﻿using Microsoft.AspNetCore.Mvc;

public class AccountController : Controller
{
    // Giriş Sayfası
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(string email, string password)
    {
        // Geçici kontrol (Daha sonra veritabanı doğrulaması eklenecek)
        if (email == "test@example.com" && password == "password")
        {
            // Başarılı giriş
            return RedirectToAction("Index", "Home");
        }
        else
        {
            // Hatalı giriş
            ViewBag.Error = "Geçersiz e-posta veya şifre.";
            return View();
        }
    }

    // Kayıt Sayfası
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(string fullName, string email, string password, string confirmPassword)
    {
        if (password != confirmPassword)
        {
            ViewBag.Error = "Şifreler eşleşmiyor.";
            return View();
        }

        // Kullanıcıyı veritabanına kaydetmek için kod eklenebilir.
        // Geçici mesaj
        ViewBag.Message = "Kayıt başarıyla tamamlandı.";
        return RedirectToAction("Login");
    }
}
